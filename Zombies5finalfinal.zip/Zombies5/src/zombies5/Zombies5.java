package zombies5;

import DAO.UsuarioDAO;
import alvos.*;
import Timers.*;
import VIEW.*;
import javax.swing.JFrame;

import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class Zombies5 extends JFrame{
    
    Timer spawnTimer, speedTimer;
    int vida;
    public Random rand = new Random(); // gerador de numero aleatório para definir a altura (y) da tela em que cada zumbia nascerá
    private final UI createUI;
    public int scoreFinal;
    public boolean caoMorto = false;
   
    
    public static void main(String[] args) {
        
        //new Zombies5(); //inicializa o jogo
       LoginVIEW janelaLogin = new LoginVIEW();
       janelaLogin.setVisible(true);
    }

    public Zombies5() {
        this.createUI = new UI(this);
        spawnTimer = new setTimer(this).getSpawnTimer(); // prepara o timer de nascimento dos zumbis (todo timer sempre precisa "set" (preparar) antes de dar o comando para ele começar)
        speedTimer = new setSpeed(this).getSpeedTimer(); // prepara o timer de movimento dos zumbis
        this.createUI.createUI(); // Inicializa a JFrame do jogo

    }

    public void StartGame() { // começa uma partido do jogo
        scoreFinal = 0;
        createUI.lbl_vida.setVisible(true);
        createUI.lbl_recorde.setVisible(true);
        vida = 5;
        createUI.lbl_vida.setText("Vidas: " + vida + " / 5"); 
        createUI.lbl_recorde.setText("Score: " + scoreFinal);
        createUI.painelMenu.setVisible(false);
        spawnTimer.start(); //começa o timer que spawna ("nasce") zumbis
        speedTimer.start();//começar o timer que movimenta os zumbis         

    }

    public void endGame() { //finaliza o jogo e prepara a tela para poder iniciar uma nova partida
        
        for (int i = createUI.zumbisVivos.size() - 1; i >= 0; i--) { //identifica quantos zumbis vivos tem
            createUI.gameLayer.remove(i);// faz um loop removendo eles da camada do jogo, um de cada vez.
        }
        createUI.zumbisVivos.clear(); //limpa a lista de zumbis que estavam vivos (apaga todos zumbis)
        spawnTimer.stop(); //para o timer de spawn
        speedTimer.stop(); // para o timer de movimento
        
         if (caoMorto == true) {
            JOptionPane.showMessageDialog(null, "O CACHORRO NÃÃÃÃOOOOO!!!!!!");
            caoMorto = false;
         }

        // da para adicionar um código que leva o jogador a uma tela de placar ou checar se ele atingiu um recorder e quer colocar o nome dele na tela de top 10 como em um arcade/fliperama
        UsuarioDAO objUsuarioDAO = new UsuarioDAO();
        boolean recorde = objUsuarioDAO.salvarNovoRecorde(LoginVIEW.nomeUsuario, scoreFinal);
        if(recorde){
           JOptionPane.showMessageDialog(null, "Novo recorde atualizado com sucesso");
       } else {
            JOptionPane.showMessageDialog(null, "Você não bateu seu recorde."); // para o jogador poder ver a pontuação final desta rodada antes de seguir para o menu
       }  
        scoreFinal = 0;
        createUI.lbl_vida.setVisible(false);
        createUI.lbl_recorde.setVisible(false);
       
        createUI.painelMenu.setVisible(true); // o menu fica visível novamente e o jogador poder iniciar um novo jogo. Este comando é basicamente o fim do loop do jogo.
    }

    public void ZombieSpawn() { // é o método que é chamado a cada Tic do relógio de nascimento dos zumbis (cada 1 segundo)
        int randomZumbi = rand.nextInt(100);
        Alvo alvo;
        if (randomZumbi < 5) {
            alvo = new alvos.Dog(this, createUI);
        } else if (randomZumbi < 20) {
            alvo = new alvos.Humano(this, createUI);
        } else if (randomZumbi < 50) {
            alvo = new ZumbiVeloz(this, createUI);
        } else {
            alvo = new alvos.ZumbiLerdo(this, createUI);
        }

        createUI.zumbisVivos.add(alvo); //adiciona esse zumbi que acaba de ser criado à lista de zumbis vivos
        createUI.gameLayer.add(alvo, javax.swing.JLayeredPane.DRAG_LAYER); //também adiciona ele à camada do jogo que é clicável

        createUI.window.revalidate(); //recalcula a aparencia da tela após a mudança de componentes presentes nela
        createUI.window.repaint();// atualiza a aparencia da tela, mostrando como ela fica sem o componente que acaba de ser removido. Ambos revalidate e repaint são necessários sempre que algo é adicionado ou removido da tela.

    }

    public void zombieWalk() { // é o método que é chamado a cada Tic do relógio de movimento dos zumbis (cada 35 milésimos)
        //a variável "i" é utilizada por convenção para se referir a um item de um vetor ("i" = "índice")
        for (int i = createUI.zumbisVivos.size() - 1; i >= 0; i--) {  // identifica quantos zumbís tem na lista zumbisVivos/quantos irão andar ao chamar esse método uma vez. ex.: zumbisVivos.getSize() se refere ao tamanho* (número total de zumbis) da lista. 
            // Se há 3 zumbis, então **seria** i = 3 . PORÉM: Lembre que listas começam sempre do 0, não do 1. Portanto, temos 3 zumbis, nos indices ZumbisVivos(0), ZumbisVivos(1) e ZumbisVivos(2).
            Alvo zombie = createUI.zumbisVivos.get(i);// Como i = zumbisVivos(que é 3) - 1, então i = 2. OU SEJA, nesta primeira volta pelo loop de movimento, iremos movimentar o zumbi no índice zumbisVivos(2), que é o último zumbi na nossa lista zumbisVivos. Como o loop defini que a cada volta i--, então no próximo loop ele moverá zumbisVivos(1), e na próxima zumbisVivos(0). No próximo, i seria igual a -1 um, e como nosso for{} definiu que o loop iria apenas enquanto 1>=0, ele encerra por aqui, tendo movimentado os 3 itens dentro da nossa lista de zumbis vivos 
            //nota extra: a JLabel zombie acima *não precisa ser criada. Eu criei ela para receber o zumbisVivos(i) de cada volta do loop apenas para ter um nome de variável mais curto para escrever no código abaixo (é mais rápido escrever "zumbi" do que "zumbisVivos(i)" várias vezes)

            // Calcula nova posição x
            int xAtual = zombie.getX(); //identifica a posição atual do zumbi dentro do eixo X da tela
            int xNovo = xAtual - zombie.getSpeed(); // calcula a nova posição do zumbi de acordo com a speed (velocidade) dele. ex.: se ele está na posição x = 700, a nova posição vai ser 700 - 8. Então a nova posição x é 692. implementarei mais velocidades quando tivermos separado as classes - vou criar uma classe abstrata "alvos" para alvos de velocidades e características diferentes
            zombie.setLocation(xNovo, zombie.getY()); //adiciona o zumbi à nova localização que foi calculada acima

            // Checar se o zumbi saiu da tela: reduz vida, apaga zumbi 
            if (xNovo + zombie.getWidth() < 0 && zombie.getHostil() == true) { // se o zumbi tem 40 pixels de larguar (e é hostil - vulgo, nao cachorro nem humano), e está na posição -41 da tela, então a soma fica -1 (que é <0) portanto realiza as ações abaixo
                vida--; //decrmenta um ponto da sua vida
                createUI.lbl_vida.setText("Vidas: " + vida + " / 5"); //para decrementar as vidas no label
                createUI.gameLayer.remove(zombie); // remove o zumbi da camada de jogo, não precisamos mais dele
                createUI.zumbisVivos.remove(i); // remove ele da lista de zumbis vivos (se nao, o loop vai continuar tentando momentar ele sempre sem necessaidade

                if (vida <= 0) { //toda vez q um zumbi passa da tela, o jogo checa se vc verdeu o jogo (vulgo, se sua vida está igual ou menor que 0). Se sim, chama o método endGame ("terminar jogo").
                    endGame();
                }
            }
        }

        createUI.window.repaint(); //desenha novamnete a janela para mostra a posição nova dos zumbis q seu movimenaram e ainda estão vivos.
    }
    
     

}
/*
um resumo do loop de métodos do jogo:

new Zombies5();
Zombies5();
createUI()
StartGame() {
        vida = 5;
        painelMenu.setVisible(false);
        spawnTimer.start();
        speedTimer.start();
}
endGame() {
        
        zumbisVivos.clear();
        spawnTimer.stop();
        speedTimer.stop();
        painelMenu.setVisible(true);
}

 */
