
package zombies5;

import DAO.UsuarioDAO;
import VIEW.InstrucoesVIEW;
import VIEW.LoginVIEW;
import VIEW.PlacarVIEW;
import alvos.Alvo;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UI {
    private Zombies5 jogo;
    public JFrame window;
    JButton btn_jogar, btn_instrucoes, btn_placar;
    public JLabel fundo, lbl_vida, lbl_recorde;
    public javax.swing.JLayeredPane gameLayer;//necessário para os zuzmbis estarem na camada mais alta e serem clicáveis
    public java.util.List<Alvo> zumbisVivos = new java.util.ArrayList<>(); // vetor/lista onde os zumbis são colocados - necessário para que o sistema possa mover cada um individualmente
    JPanel painelMenu;
    private final listener listener = new listener(); // listener para clicar nos botões do menu
    
    
    public UI(Zombies5 jogo) { 
        this.jogo = jogo; // Stores the ONE running game object
    }
    
    public void createUI() {
                
        window = new JFrame(); // janela do jogo
        window.setSize(800, 700);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().setBackground(Color.black);
        window.setLayout(null);
        
        java.net.URL path = getClass().getResource("/fundo800x700.jpg");
        javax.swing.ImageIcon imagemFundo = new javax.swing.ImageIcon(path);
        fundo = new JLabel(imagemFundo);
        fundo.setBounds(0,0,800,700);
        
        //label de vida 
        lbl_vida = new JLabel("");
        lbl_vida.setBounds(20,15,100,50);
        lbl_vida.setFont(new Font("Arial",Font.BOLD,15));
        lbl_vida.setForeground(Color.RED);
        lbl_vida.setOpaque(false);
        lbl_vida.setVisible(false);
        
        
        //label de pontuação
        lbl_recorde = new JLabel("Score: 0");
        lbl_recorde.setBounds(650,15,100,50);
        lbl_recorde.setFont(new Font("Arial",Font.BOLD,15));
        lbl_recorde.setForeground(Color.RED);
        lbl_recorde.setOpaque(false);
        lbl_recorde.setVisible(false);
        
        //necessário para os zuzmbis estarem na camada mais alta da janela e serem clicáveis
        gameLayer = new javax.swing.JLayeredPane();
        gameLayer.setBounds(0, 0, 800, 700);
        window.add(gameLayer);
        gameLayer.add(fundo, Integer.valueOf(Integer.MIN_VALUE));
        
        //adicionando os labels de vida e recorde na camada do jogo
        gameLayer.add(lbl_vida, javax.swing.JLayeredPane.DEFAULT_LAYER);
        gameLayer.add(lbl_recorde, javax.swing.JLayeredPane.DEFAULT_LAYER);

        painelMenu = new JPanel(); //Painel que contem os ícones e botões do menu inicial. Adicionar todos os itens do menu aqui - daí, quando o jogo inicia, só precisa de um comando de setVisible(false) pra fazer tudo e partir para a tela de jogo.
        painelMenu.setBounds(80, 170, 250, 250);
        painelMenu.setBackground(Color.blue);
        painelMenu.setLayout(new GridLayout(3, 1)); //um grid de 3 botões - fiz assim apra usar menos linhas de codigo e n ter q posicionar cada botao individualmente. Com mais tempo, podemos separar os botões por estética 
        gameLayer.add(painelMenu, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn_jogar = new JButton("Jogar");
        btn_jogar.setFocusPainted(false);
        painelMenu.add(btn_jogar);
        btn_jogar.addActionListener(listener);
        btn_jogar.setActionCommand("act_jogar"); // manda a ação "jogar" para o listener (no fundo do documento)

        btn_instrucoes = new JButton("Instruções"); //a programar
        btn_instrucoes.setFocusPainted(false);
        painelMenu.add(btn_instrucoes);
        btn_instrucoes.addActionListener((ActionEvent e) -> {
        InstrucoesVIEW telaInstrucao = new InstrucoesVIEW();  // cria a nova janela
        telaInstrucao.setVisible(true);  // exibe a nova janela
        telaInstrucao.setLocationRelativeTo(null);
        telaInstrucao.setResizable(false);
        });

        btn_placar = new JButton("Placar"); 
        btn_placar.setFocusPainted(false);
        painelMenu.add(btn_placar);
        btn_placar.addActionListener((ActionEvent e) -> {
        PlacarVIEW telaPlacar = new PlacarVIEW();  // cria a nova janela
        telaPlacar.setLocationRelativeTo(null);
        telaPlacar.setResizable(false);
        UsuarioDAO objUsuarioDAO = new UsuarioDAO();
        ResultSet placar = objUsuarioDAO.mostrarPlacar(LoginVIEW.nomeUsuario);
        try{
            if(placar.next()){
              int recorde = placar.getInt("recorde_usuario");
              telaPlacar.setHighScore(String.valueOf(recorde));
              
              telaPlacar.setVisible(true);  // exibe a nova janela com o recorde
            }
        }catch(SQLException erro){
           JOptionPane.showMessageDialog(null, "Erro btn_placar, PlacarVIEW:"+
                   erro.getMessage());
        }
        });

        window.setVisible(true);
    }
        public class listener implements ActionListener { // listener para ouvir os cliques dos botões do menu principal

        @Override
        public void actionPerformed(ActionEvent event) {

            String action = event.getActionCommand(); //recebe os comandos do listener

            switch (action) { // um switch case  que identifica o comando que é dado por cada botão clicado do menu

                case "act_jogar": //"act_jogar" ("act" seria uma abreviação para "action") é o comando que o listener recebeu ao clicar o botão "Jogar". Portanto, ele chama o método StartGame().
                    UI.this.jogo.StartGame();
            }

        }
    }
        
}
