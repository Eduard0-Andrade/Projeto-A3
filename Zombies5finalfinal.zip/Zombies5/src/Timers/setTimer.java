package Timers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import zombies5.Zombies5;

public class setTimer {
    
    private final Zombies5 jogo;
    private final Timer spawnTimer;
    
    public setTimer(Zombies5 jogo) { // prepara/define o Timer de nascimento dos zumbis
        this.jogo = jogo;
        spawnTimer = new Timer(700, new ActionListener() { // define que o Timer (relógio) irá "Ticar" a cada 1000 milésimos (vulgo, 1 segundo)
            @Override
            public void actionPerformed(ActionEvent e) { //define a ação que o relógio realizará a cada Tic do relógio. A cada tic (1 segundo) deste relógio, chama o método ZombieSpawn
                jogo.ZombieSpawn();
            }
        });
    }
    
    public Timer getSpawnTimer() {
        return spawnTimer;
    }
}
