
package Timers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import zombies5.Zombies5;

public class setSpeed {
    
    private final Zombies5 jogo;
    private final Timer speedTimer;
    
    public setSpeed (Zombies5 jogo){
        this.jogo = jogo;
        
        speedTimer = new Timer(20, new ActionListener() { // define que o Timer (relógio) irá "Ticar" a cada 30 milésimos
            @Override
            public void actionPerformed(ActionEvent e) { //define a ação que o relógio realizará a cada Tic do relógio. A cada tic (1 segundo) deste relógio, chama o método ZombieSpawn
                jogo.zombieWalk();
            }
        });
        
    }
    
    public Timer getSpeedTimer() {
        return speedTimer;
    }
    
}
