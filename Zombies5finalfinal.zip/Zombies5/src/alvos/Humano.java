package alvos;


import javax.swing.ImageIcon;
import zombies5.*;

public class Humano extends Alvo {

        private static final String[] SpritesHumanos = {
        "Survivor1.png",
        "Survivor2.png",
        "Survivor3.png",
        "Survivor4.png"
    };
    
    public Humano(Zombies5 jogo, UI UI) {
        super(6, -60, jogo, UI, false);
        this.setIconeAlvo();
        this.setOpaque(false);
    }


    @Override
    public void setIconeAlvo() {
        String RandomSpritesHumanos = SpritesHumanos[this.rando.nextInt(SpritesHumanos.length)];
        java.net.URL imageURL = getClass().getClassLoader().getResource(RandomSpritesHumanos);
        ImageIcon zombieIcon = new ImageIcon(imageURL);
        setIcon(zombieIcon);
    }
    @Override
    public void mousePressed(java.awt.event.MouseEvent e) {
        java.awt.Rectangle humanoMorto = this.getBounds(); // recupera a localização onde o humano morreu antes de removê-lo
        UI.gameLayer.remove(this); 
        UI.zumbisVivos.remove(this);
        
        ZumbiVeloz novoZumbi = new ZumbiVeloz(jogo, UI);
        novoZumbi.setBounds(humanoMorto);
        UI.zumbisVivos.add(novoZumbi); //adiciona esse zumbi que acaba de ser criado à lista de zumbis vivos
        UI.gameLayer.add(novoZumbi, javax.swing.JLayeredPane.DRAG_LAYER);// adiciona à camada do jogo
                    
        UI.window.revalidate(); 
        UI.window.repaint(); 
        
        jogo.scoreFinal += getValorPontos(); 
        UI.lbl_recorde.setText("Score: " + jogo.scoreFinal);
    }
    
}
