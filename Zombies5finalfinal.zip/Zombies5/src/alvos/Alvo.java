package alvos;

import javax.swing.JLabel;
import java.awt.event.MouseListener;
import java.util.Random;
import zombies5.*;

public abstract class Alvo extends JLabel implements MouseListener {

    protected int speed;
    protected int valorPontos;
    protected Zombies5 jogo;
    protected boolean hostil;
    protected Random rando;
    protected UI UI;
    //protected scoreFinal = jogo.scoreFinal;

    public Alvo(int speed, int valorPontos, Zombies5 jogo, UI UI,  boolean hostil) {
        this.speed = speed;
        this.valorPontos = valorPontos;
        this.jogo = jogo;
        this.rando = new Random();
        this.hostil = hostil;
        this.UI = UI;
        
        int spawnX = UI.window.getWidth();
        int spawnY = rando.nextInt(UI.window.getHeight() - 120);
        setBounds(spawnX, spawnY, 72, 120);
        
        setVisible(true);
        addMouseListener(this); //seria possivel um erro caso o objeto fosse clicado antes dele terminar de ser gerado - no nosso caso, isso não ocorrerá no nosso jogo
        
    }
    
    public void makeBounds(int dogWidth, int dogHeight) {
        int spawnX = UI.window.getWidth();
        int spawnY = rando.nextInt(UI.window.getHeight() - 120);
        this.setBounds(spawnX, spawnY, dogWidth, dogHeight);
    }
   public abstract void setIconeAlvo();
   
  
   public int getSpeed(){
       return speed;
   }
   
   public int getValorPontos(){
       return valorPontos;
   }
   
   public boolean getHostil() {
       return hostil;
   }
   
   @Override
    public void mousePressed(java.awt.event.MouseEvent e) {
        
        UI.gameLayer.remove(this); 
        UI.zumbisVivos.remove(this); 
        
        UI.window.revalidate(); 
        UI.window.repaint(); 
        
        jogo.scoreFinal += getValorPontos(); 
        UI.lbl_recorde.setText("Score: " + jogo.scoreFinal);
    }
   
    @Override public void mouseClicked(java.awt.event.MouseEvent e) {} // aparentemnete é obrigatório ter esses outros 4 declarados quando implementa o mouselistener, mesmo sem fazer nada com eles?
    @Override public void mouseReleased(java.awt.event.MouseEvent e) {}
    @Override public void mouseEntered(java.awt.event.MouseEvent e) {}
    @Override public void mouseExited(java.awt.event.MouseEvent e) {}
}
