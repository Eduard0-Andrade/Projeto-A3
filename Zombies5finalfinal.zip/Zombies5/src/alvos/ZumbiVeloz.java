
package alvos;

import zombies5.*;
import javax.swing.ImageIcon;

public class ZumbiVeloz extends Alvo{
    
    private static final String[] SpritesZumbis = {
        "FastnotTaylor72x120.png", 
        "FastnotHitler72x120.png", 
        "FastnotStalin72x120.png", 
        "FastnotPutin72x120.png", 
        "FastnotTrump72x120.png"
    };
    
    public ZumbiVeloz(Zombies5 jogo, UI UI) {
        super (7, 150, jogo, UI, true);
        this.setIconeAlvo();
        
        this.setOpaque(false);
        
    }
      
    @Override
    public void setIconeAlvo() {
        String spriteZumbiRandom = SpritesZumbis[this.rando.nextInt(SpritesZumbis.length)];
        java.net.URL imageURL = getClass().getClassLoader().getResource(spriteZumbiRandom); 
        ImageIcon zombieIcon = new ImageIcon(imageURL);
        setIcon(zombieIcon);
        
    }
    
}
