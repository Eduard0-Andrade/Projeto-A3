package alvos;

import zombies5.*;
import javax.swing.ImageIcon;

public class ZumbiLerdo extends Alvo {

    private static final String[] SpritesZumbis = {
        "notTaylor72x120.png", 
        "notHitler72x120.png", 
        "notStalin72x120.png", 
        "notPutin72x120.png", 
        "notTrump72x120.png"
    };
    
    public ZumbiLerdo(Zombies5 jogo, UI UI) {
        super(5, 100, jogo, UI, true);
        this.setIconeAlvo();

    }

    @Override
    public void setIconeAlvo() {
        String spriteZumbiRandom = SpritesZumbis[this.rando.nextInt(SpritesZumbis.length)];
        java.net.URL imageURL = getClass().getClassLoader().getResource(spriteZumbiRandom);
        ImageIcon zombieIcon = new ImageIcon(imageURL);
        setIcon(zombieIcon);
        setOpaque(false);

    }
  

}
