package alvos;

import zombies5.*;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Dog extends Alvo {
 
    private static final int DOG_WIDTH = 100;
    private static final int DOG_HEIGHT = 80;
    
    public Dog(Zombies5 jogo, UI UI) {
        super(8, -500, jogo, UI, false);
        this.setIconeAlvo();
        this.setOpaque(false);
    }

    @Override
    public void setIconeAlvo() {
        java.net.URL imageURL = getClass().getClassLoader().getResource("DOG100x80.png");
        makeBounds(DOG_WIDTH, DOG_HEIGHT);
        ImageIcon zombieIcon = new ImageIcon(imageURL);
        setIcon(zombieIcon);
    }
    @Override
    public void mousePressed(java.awt.event.MouseEvent e) {
       jogo.scoreFinal += getValorPontos(); 
       UI.lbl_recorde.setText("Score: " + jogo.scoreFinal);
       
       jogo.caoMorto = true;
       jogo.endGame();    // precisa fazer com que a remoção de todos zumibis da tela passe para endgame, nao zombieWalk   
           
        UI.window.revalidate(); 
        UI.window.repaint(); 
           
    }
    
}
