package DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.SQLException;
public class ConexaoDAO {
    //atributos
    private String url = "jdbc:mysql://localhost:3306/db_zumbi";
    private String nome = "root";// ****TROCAR POR NOME DA MAQUINA****
    // <editor-fold>
    private String senha = "";//*****ADICIONAR SENHA DA MAQUINA****
   // </editor-fold>
    private Connection conn;
    
    //comportamentos
    public Connection conectarBD(){
        try{
            conn = DriverManager.getConnection(url,nome,senha);
            //JOptionPane.showMessageDialog(null, "Conectado ao banco");
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro em conectarBD, ConexaoDAO:"+
                    erro.getMessage());
        }
        return conn;
    }
}
