package DAO;

import DTO.UsuarioDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UsuarioDAO {
    //atributos
    private Connection conn;
    String nomeConectado = "";
    
    //comportamentos
    public ResultSet autenticarUsuario(UsuarioDTO objUsuarioDTO){
        conn = new ConexaoDAO().conectarBD();
        try{
            String sql  = "select * from usuario where nome_usuario = ? and senha_usuario = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, objUsuarioDTO.getNome());
            pstm.setString(2, objUsuarioDTO.getSenha());
            ResultSet rs = pstm.executeQuery();
            
            return rs;
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro em autenticarUsuario, UsuarioDAO:"+
                    erro.getMessage());
        }
        return null;
    }
    
    public ResultSet checarUsuario(UsuarioDTO objUsuarioDTO){
        conn = new ConexaoDAO().conectarBD();
        try{
            String sqlch = "select id from usuario where nome_usuario=?";
            PreparedStatement pstm = conn.prepareStatement(sqlch);
            pstm.setString(1, objUsuarioDTO.getNome());
            ResultSet checagem = pstm.executeQuery(); 
            return checagem;
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro em cadastrarUsuario, UsuarioDAO:"+
                    erro.getMessage());
        } 
        return null;
    }
    
    public boolean cadastrarUsuario(UsuarioDTO objUsuarioDTO){
        conn = new ConexaoDAO().conectarBD();
        try{
            String sqlc = "insert into usuario(nome_usuario,senha_usuario,recorde_usuario)"
                    + "values(?,?,?)";
            PreparedStatement pstm = conn.prepareStatement(sqlc);
            pstm.setString(1, objUsuarioDTO.getNome());
            pstm.setString(2, objUsuarioDTO.getSenha());
            pstm.setInt(3, 0);
            int cadastro = pstm.executeUpdate();
            return cadastro > 0;
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro em cadastrarUsuario, UsuarioDAO:"+
                    erro.getMessage());
            return false;
        } 
    }
    public boolean salvarNovoRecorde(String nomeUsuario, int novoRecorde){
        conn = new ConexaoDAO().conectarBD();
        try{
            String sqlr = "update usuario set recorde_usuario = ? where nome_usuario = ? and recorde_usuario < ?";
            PreparedStatement pstm = conn.prepareStatement(sqlr);
            pstm.setInt(1, novoRecorde);
            pstm.setString(2, nomeUsuario);
            pstm.setInt(3, novoRecorde); //para verificar se o novo score é maior do que o já salvo antes de fazer o update
            int recorde = pstm.executeUpdate();
            return recorde > 0;
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro em salvarNovoRecorde, UsuarioDAO:"+
                    erro.getMessage());
            return false;
        } 
    }
    
    public ResultSet mostrarPlacar(String nomeUsuario){
        conn = new ConexaoDAO().conectarBD();
        try{
            String sqlp  = "select recorde_usuario from usuario where nome_usuario = ?";
            PreparedStatement pstm = conn.prepareStatement(sqlp);
            pstm.setString(1, nomeUsuario);
            
            ResultSet placar = pstm.executeQuery();
            
            return placar;
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro em mostrarPlacar, UsuarioDAO:"+
                    erro.getMessage());
        }
        return null;
    }
    
    
}

